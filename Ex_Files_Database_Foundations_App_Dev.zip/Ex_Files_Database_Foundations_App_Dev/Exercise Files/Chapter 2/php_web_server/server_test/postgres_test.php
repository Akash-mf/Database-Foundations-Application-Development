<!DOCTYPE html>
<html>
<head>
	<title>PostgreSQL Information</title>
	<link rel="stylesheet" type="text/css" href="../stylesheet.css"/>
</head>
<body>
<?php
echo "<h2>PostgreSQL Version information:</h2>";

echo "<h3>";

$db_connection = pg_connect("host=pg_db_server port=5432 dbname=postgres user=postgres password=Adam123456");
$sql_query = "SELECT version();";
$result = pg_query($db_connection, $sql_query);

while ($row = pg_fetch_array($result)) {
    echo $row[0];
}
echo "</h3><hr />";

echo "<h3>Connection Information:</h3>";
echo "Database Name: " . pg_dbname($db_connection) . "<br>";
echo "Host Name: " . pg_host($db_connection) . "<br>";
echo "Port: " . pg_port($db_connection) . "<br>";

pg_close($db_connection);
?>
</body>
</html>