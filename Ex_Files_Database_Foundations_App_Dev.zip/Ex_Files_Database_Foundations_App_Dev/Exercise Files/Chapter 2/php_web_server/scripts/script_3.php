<!DOCTYPE html>
<html>
<head>
	<title>Query 3</title>
	<link rel="stylesheet" type="text/css" href="/stylesheet.css"/>
</head>
<body>
<?php
	echo "<h3>Attempting to drop the database...</h3>";

// Store connection, query, and results as PHP variables
	$db_connection = pg_connect("host=pg_db_server port=5432 dbname=postgres user=postgres password=Adam123456");
	$sql_query = "DROP DATABASE test WITH ( FORCE );";
	$result = @pg_query($db_connection, $sql_query);

// Verify results and display a message on success or failure
	if ($result) {
		echo "<h3>The database was successfully dropped.</h3>";
	} else {
		echo "<h3>The query failed with the following error:</h3>";
		echo pg_last_error($db_connection);
	}

// Close the connection to the PostgreSQL server
	pg_close($db_connection);
?>
</body>
</html>