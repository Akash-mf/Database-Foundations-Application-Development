<!DOCTYPE html>
<html>
<head>
	<title>Query 2</title>
	<link rel="stylesheet" type="text/css" href="/stylesheet.css"/>
</head>
<body>
<?php
	echo "<h3>Creating a table in the test database</h3>";

// Store connection and query as php variables
	$db_connection = pg_connect("host=pg_db_server port=5432 dbname=test user=postgres password=Adam123456");
	$sql_query = "CREATE TABLE testing(id integer);";

// Use the variables in the pg_query function	
	pg_query($db_connection, $sql_query);

// Close the connection to the PostgreSQL database
	pg_close($db_connection);

	echo "<h3>Table Created!</h3>";
?>
</body>
</html>