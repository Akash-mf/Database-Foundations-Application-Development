<!DOCTYPE html>
<html>
<head>
	<title>Query 1</title>
	<link rel="stylesheet" type="text/css" href="/stylesheet.css"/>
</head>
<body>
<?php
	echo "<h3>Creating a new database named 'test'</h3>";

// Connect to the Postgres server and execute a query
	pg_connect("host=pg_db_server port=5432 dbname=postgres user=postgres password=Adam123456");
	pg_query("CREATE DATABASE test;");

	echo "<h3>Database created!</h3>";
?>
</body>
</html>