<!DOCTYPE html>
<html>
<head>
	<title>PostgreSQL Database Server Connection</title>
	<link rel="stylesheet" type="text/css" href="/stylesheet.css"/>
</head>
<body>
	<h1>Success!</h1>
	<hr />
	<h3><?php echo "Today is " . date("l, F jS, Y") . "<br>" . date("h:i:s A \U\T\C");?></h3>
	<p><a href="/server_test/phpinfo.php" target="_blank">View PHP information</a></p>
	<p><a href="/server_test/postgres_test.php" target="_blank">View PostgreSQL information</a></p>
	<hr />

	<h2>PHP Script 1: Create Database</h2>
	<p>The following code will connect to the PostgreSQL server and execute a CREATE DATABASE command. The PHP web server uses <a href="https://www.php.net/manual/en/ref.pgsql.php" target="_blank">PostgreSQL functions</a> to send commands to the database server.</p>
	<div class="code-box-title">Contents of <strong>script_1.php</strong></div>
	<div class="code-box"><code><?php highlight_file('scripts/script_1.php')?></code></div>
	<form action="/scripts/script_1.php">
	 	<input type="submit" value="Run script_1.php">
	</form>
	<br><hr />

	<h2>PHP Script 2: Create Table</h2>
	<p>In PHP, <a href="https://www.php.net/manual/en/language.variables.basics.php" target="_blank">variables</a> are created with the dollar sign $. We can use variables to hold the PostgreSQL connection string and query syntax to make the code easier to reuse.</p>
	<div class="code-box-title">Contents of <strong>script_2.php</strong></div>
	<div class="code-box"><code><?php highlight_file('scripts/script_2.php')?></code></div>
	<form action="/scripts/script_2.php">
	 	<input type="submit" value="Run script_2.php">
	</form>
	<br><hr />

	<h2>PHP Script 3: Drop Database</h2>
	<p>The <a href="https://www.php.net/manual/en/control-structures.else.php" target="_blank">if / else control construct</a> in PHP allows you to create conditional code that executes different blocks, depending on the outcome of a test. This is useful for integrating error handling into the routine.</p>
	<div class="code-box-title">Contents of <strong>script_3.php</strong></div>
	<div class="code-box"><code><?php highlight_file('scripts/script_3.php')?></code></div>
	<form action="/scripts/script_3.php">
	 	<input type="submit" value="Run script_3.php">
	</form>
	<br><hr />
	<p><strong>Next Steps:</strong> Working with the <a href="/two_trees/index.php">Two Trees Olive Oil</a> database.</p>
</body>
</html>




