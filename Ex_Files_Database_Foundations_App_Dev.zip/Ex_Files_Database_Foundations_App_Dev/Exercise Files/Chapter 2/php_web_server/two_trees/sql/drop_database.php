<!DOCTYPE html>
<html>
<head>
	<title>Two Trees</title>
	<link rel="stylesheet" type="text/css" href="/stylesheet.css"/>
</head>
<body>
<?php
	echo "<h3>Attempting to drop the database... </h3>";

	$db_connection = pg_connect("host=pg_db_server port=5432 dbname=postgres user=postgres password=Adam123456");
	$sql_query = "DROP DATABASE two_trees WITH ( FORCE );";
	$result = @pg_query($db_connection, $sql_query);

	if ($result) {
		echo "<p>The Two Trees database was successfully dropped.</p>";
	} else {
		echo "<p>The query failed with the following error: </p><br>";
		echo pg_last_error($db_connection);
	}
	pg_close($db_connection);
?>
</body>
</html>