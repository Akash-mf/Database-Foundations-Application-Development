<!DOCTYPE html>
<html>
<head>
	<title>Two Trees</title>
	<link rel="stylesheet" type="text/css" href="/stylesheet.css"/>
</head>
<body>
<?php
	
// Query the database
	$db_connection = pg_connect("host=pg_db_server port=5432 dbname=two_trees user=postgres password=Adam123456");
	$query_db = "SELECT sku, product_name, category_id, size, price FROM inventory.products;";
	$result = pg_query($db_connection, $query_db);

// Display the results as a table
 	if ($result) {
		echo "<p>The query executed successfully.</p>";
		echo "<h3>Two Trees Product Information:</h3>";

		echo "<table>
				<tr>
				    <th>sku</th>
				    <th>product_name</th> 
				    <th>category_id</th>
				    <th>size</th>
				    <th>price</th>
				</tr>";

		for ($row = 0; $row < pg_num_rows($result); $row++) {
			$sku = pg_fetch_result($result, $row, 'sku');
			$product_name = pg_fetch_result($result, $row, 'product_name');
			$category_id = pg_fetch_result($result, $row, 'category_id');
			$size = pg_fetch_result($result, $row, 'size');
			$price = pg_fetch_result($result, $row, 'price');

			echo "<tr>
					<td>" . $sku . "</td>
					<td>" . $product_name . "</td>
					<td>" . $category_id . "</td>
					<td>" . $size . "</td>
					<td>" . $price ."</td>
				  </tr>";
		}	
	}
	else {
		echo "The query failed with the following error:<br>";
		echo pg_last_error($db_connection);
	}
	echo "</table>";
	pg_close($db_connection);
?>
</body>
</html>