<!DOCTYPE html>
<html>
<head>
	<title>Two Trees</title>
	<link rel="stylesheet" type="text/css" href="/stylesheet.css"/>
</head>
<body>
<?php

// Prepare and execute the INSERT query
	$db_connection = pg_connect("host=pg_db_server port=5432 dbname=two_trees user=postgres password=Adam123456");
	$result = pg_prepare($db_connection, "my_query", 'INSERT INTO inventory.products (sku, product_name, category_id, size, price)
														VALUES ($1, $2, $3, $4, $5);');
	$result = @pg_execute($db_connection, "my_query", array($_POST['sku_value'],
															$_POST['name_value'],
															$_POST['category_id_value'],
															$_POST['size_value'],
															$_POST['price_value']));

// Verify successful insert 	
 	if ($result) {
 		echo "<h3>The row was inserted.</h3>";
 		echo "<p>SKU: " . $_POST['sku_value'] . "<br>";
 		echo "Product Name: " . $_POST['name_value'] . "<br>";
 		echo "Category ID: " . $_POST['category_id_value'] . "<br>";
 		echo "Size: " . $_POST['size_value'] . "<br>";
 		echo "Price: " . $_POST['price_value'] . "</p>";
	} else {
		echo "<h3>The insert failed with the following error:</h3><br>";
		echo pg_last_error($db_connection);
	}

// Close the connection
	pg_close($db_connection);
?>
</body>
</html>