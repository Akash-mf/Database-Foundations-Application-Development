<!DOCTYPE html>
<html>
<head>
	<title>Two Trees</title>
	<link rel="stylesheet" type="text/css" href="../stylesheet.css"/>
</head>
<body>
	<h1>Two Trees Database</h1>
	<hr />
	
	<h2>Set up the Two Trees Olive Oil Company database:</h2>
	<p><a href = 'https://www.twotreesoliveoil.com'>Two Trees</a> produces a line of olive oil products.<br>
	The following php code will create a database, add a table, and populate it with sample data.</p>
	<p>Pressing the <strong>CREATE</strong> button below executes the script found in <em>two_trees/sql/create_database.php</em><br>
	Pressing the <strong>DROP</strong> button executes the script found in <em>two_trees/sql/drop_database.php</em></p>
	<div class="code-box-title">Contents of <strong>create_database.php</strong></div>
	<div class="code-box"><code><?php highlight_file('sql/create_database.php')?></code></div>
	<form action="sql/create_database.php">
	 	<input type="submit" value="CREATE the Two Trees Database">
	</form><br>
	<form action="sql/drop_database.php" method="get">
	 	<input type="submit" value="DROP the Two Trees Database">
	</form>
	<br><hr />

	

	<h2>Query 1: Query the table and display results</h2>
	<p>Select query. Pressing the button below executes the code found in <em>two_trees/sql/query_1.php</em></p>
	<div class="code-box-title">Contents of <strong>query_1.php</strong></div>
	<div class="code-box"><code><?php highlight_file('sql/query_1.php')?></code></div>
	<form action="sql/query_1.php">
	 	<input type="submit" value="Run Query 1">
	</form>
	<br><hr />



	<h2>Query 2: Format the results as an HTML table</h2>
	<p>SELECT query formatted as html table. Pressing the button below executes the code found in <em>two_trees/sql/query_2.php</em></p>
	<div class="code-box-title">Contents of <strong>query_2.php</strong></div>
	<div class="code-box"><code><?php highlight_file('sql/query_2.php')?></code></div>
	<form action="sql/query_2.php">
	 	<input type="submit" value="Run Query 2">
	</form>
	<br><hr />



	<h2>Query 3: Pass user input to filter the results using a WHERE clause</h2>
	<p>SELECT query with input. Pressing the button below executes the code found in <em>two_trees/sql/query_3.php</em></p>
	<form action = "sql/query_3.php" method = "post">
		<label>Select Product Category:</label>
		<select name="category_id_value">
	    	<option value="1">1: Olive Oils</option>
	    	<option value="2">2: Flavor Infused Oils</option>
	    	<option value="3">3: Bath and Beauty</option>
		</select>
		<input type="submit" value="Run Query 3"/>
	</form>
	<br>
	<div class="code-box-title">Contents of <strong>query_3.php</strong></div>
	<div class="code-box"><code><?php highlight_file('sql/query_3.php')?></code></div>
	<br><hr />



	<h2>Query 4: Add new rows to the table</h2>
	<p>INSERT query with input. Pressing the button below executes the code found in <em>two_trees/sql/query_4.php</em></p>
	<form action = "sql/query_4.php" method = "post">

		<label>SKU:</label>
			<input type="text" name="sku_value"><br>
		<label>Product Name:</label>
			<input type="text" name="name_value"><br>
		<label>Select Product Category:</label>
			<select name="category_id_value">
		    	<option value="1">1: Olive Oils</option>
		    	<option value="2">2: Flavor Infused Oils</option>
		    	<option value="3">3: Bath and Beauty</option>
			</select><br>
		<label>Size:</label>
			<input type="text" name="size_value"><br>
		<label>Price:</label>
			<input type="text" name="price_value"><br>

		<input type="submit" value="Run Query 4"/>
	</form>
	<br>
	<div class="code-box-title">Contents of <strong>query_4.php</strong></div>
	<div class="code-box"><code><?php highlight_file('sql/query_4.php')?></code></div>
	<br><hr />

</body>
</html>