﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace app.Models
{
    public class Customer
    {
        public int Id { get; set; }

        [Display(Name = "Customer ID")]
        [Required]
        [StringLength(5, MinimumLength = 5)]
        [RegularExpression(@"^[A-Z]{2}[0-9]{3}$")]
        public string customer_id { get; set; }

        [Display(Name = "Company Name")]
        [StringLength(100)]
        [RegularExpression(@"^[a-zA-Z ]*$")]
        public string company { get; set; }

        [Display(Name = "Street Address")]
        [StringLength(100)]
        public string address { get; set; }

        [Display(Name = "City")]
        [StringLength(50)]
        public string city { get; set; }

        [Display(Name = "State")]
        [StringLength(2, MinimumLength = 2)]
        [RegularExpression(@"^[A-Z]{2}$")]
        public string state { get; set; }

        [Display(Name = "Zip Code")]
        [StringLength(5, MinimumLength = 5)]
        public string zip { get; set; }
    }
}