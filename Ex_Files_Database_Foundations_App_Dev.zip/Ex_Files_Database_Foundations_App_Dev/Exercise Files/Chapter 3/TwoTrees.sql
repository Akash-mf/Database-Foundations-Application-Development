-- Create the Two Trees database
CREATE DATABASE TwoTrees;
GO

USE TwoTrees;
GO

-- Create a table for the Two Trees customer data
CREATE TABLE customer (
    Id          INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    customer_id CHAR(5) NOT NULL,
    company     VARCHAR(100),
    address     VARCHAR(100),
    city        VARCHAR(50),
    state       CHAR(2),
    zip         CHAR(5),
    CONSTRAINT UQ_Id UNIQUE (Id)
);

-- Add data to the customer table
INSERT INTO customer VALUES
    ('FV418', 'Flavorville', '798 Ravinia Road', 'Des Moines', 'IA', '50320'),
    ('WR421', 'Wild Rose', '222 Dakota Lane', 'Kalamazoo', 'MI', '49001'),
    ('BX305', 'Bread Express', '3362 Ute Loop', 'Tiffin', 'OH', '44883'),
    ('BV446', 'Blue Vine', '40675 Raymond Curve', 'Columbus', 'GA', '31901'),
    ('GR208', 'Green Gardens', '394 Mesa Palms Avenue', 'Glen Campbell', 'PA', '15742'),
    ('DF600', 'Delish Food', '809 Weathersfield Ctr Park', 'Madisonville', 'OH', '45227')
;